package com.example.apataker.probuddy;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Register extends AppCompatActivity {
    TextView t1,t2,t3;
    Button mb1;
    ImageView i;
    EditText e1,e2,e3,e4,e5;
    private DatabaseReference db;
    private FirebaseAuth firebaseAuth;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.register);
        progressBar=(ProgressBar)findViewById(R.id.pbRegi);
        db= FirebaseDatabase.getInstance().getReference();
        firebaseAuth=FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() !=null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(),Activity.class));
        }
        t1=(TextView)findViewById(R.id.nametext);
        t2=(TextView)findViewById(R.id.emailtext);
        t3=(TextView)findViewById(R.id.phonetext);
        mb1=(Button)findViewById(R.id.next);
        e1=(EditText)findViewById(R.id.nameedit);
        e2=(EditText)findViewById(R.id.emailedit);
        e3=(EditText)findViewById(R.id.phoneedit);
        e4=(EditText)findViewById(R.id.useredit2);
        e5=(EditText)findViewById(R.id.passedit2);
// Write a message to the database
//        Toast.makeText(this,"SignUP",1000).show();

        mb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                HashMap<String,String> datamap=new HashMap<String, String>();
                registerUser();
//                DatabaseReference myRef = db.getReference().push();
//                DatabaseReference mRefName = myRef.child("Name");
//                DatabaseReference mRefEmail = myRef.child("Email");
//                DatabaseReference mRefPhoneNo = myRef.child("PhoneNo");
//                DatabaseReference mRefusername = myRef.child("username");
//                DatabaseReference mRefpassword = myRef.child("password");
//                mRefName.setValue(e1.getText().toString());
//                mRefEmail.setValue(e2.getText().toString());
//                mRefPhoneNo.setValue(e3.getText().toString());
//                mRefusername.setValue(e4.getText().toString());
//                mRefpassword.setValue(e5.getText().toString());
//                datamap.put("Name",e1.getText().toString().trim());
//                datamap.put("Email",e2.getText().toString().trim());
//                datamap.put("PhoneNo",e3.getText().toString().trim());
//                datamap.put("username",e4.getText().toString().trim());
//                datamap.put("password",e5.getText().toString().trim());
//                db.push().setValue(datamap);
//                Intent obj2=new Intent(register.this,Login.class);
//                startActivity(obj2);
// mRefName.setValue("melada");
            }
        });
    }
    private void registerUser()
    {
        final String name,email,phoneNo;
        name= e1.getText().toString().trim();
        email=e2.getText().toString().trim();
        phoneNo=e3.getText().toString().trim();
        String username=e4.getText().toString().trim();
        String password=e5.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Please Enter Email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Please Enter Password",Toast.LENGTH_SHORT).show();
            return;
        }
        String id =db.push().getKey();
        Details details = new Details(id,name,email,phoneNo,username,password);
        db.child(id).setValue(details);
//        progressBar.setMax(100());
        progressBar.setVisibility(View.VISIBLE);
        firebaseAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Register.this," Registered Sucessfull",Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                            finish();
                            startActivity(new Intent(getApplicationContext(),Activity.class));
                        }else{
                            Toast.makeText(Register.this," Could not register,Try again",Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                        }
                    }
                });

    }
}
