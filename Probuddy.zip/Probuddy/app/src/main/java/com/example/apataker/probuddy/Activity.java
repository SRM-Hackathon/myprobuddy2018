package com.example.apataker.probuddy;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Activity extends AppCompatActivity {
    TextView t1;
    Button b1,b2,b3,b4,b5;
    FirebaseAuth firebaseAuth;
    private DatabaseReference db= FirebaseDatabase.getInstance().getReference();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_);
        t1 = (TextView)findViewById(R.id.welcomeDisplay);
        b1 = (Button)findViewById(R.id.cylometric);
        b2 = (Button)findViewById(R.id.game);
        b3 = (Button)findViewById(R.id.socialP);
        b4 = (Button)findViewById(R.id.logout);
        b5 = (Button)findViewById(R.id.button2);
        firebaseAuth = FirebaseAuth.getInstance();
//        if(firebaseAuth.getCurrentUser() == null)
//        {
//            finish();
//            startActivity(new Intent(getApplicationContext(),Login.class));
//        }
        FirebaseUser user = firebaseAuth.getCurrentUser();
//        db.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });

        String email=user.getEmail();
//        String key=db.getKey().toString();
        t1.setText("Welcome "+email);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/forms/d/e/1FAIpQLSceQkEL-Aav_PdZBYMWw9bPRdFRICnksjTZ5BOCfZcEsi7xTA/viewform?usp=sf_link"));
                startActivity(browserIntent);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                finish();
                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://klout.com/home"));
                startActivity(browserIntent);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/2017probuddy/?ref=br_rs"));
                startActivity(browserIntent);
            }
        });

    }
}
