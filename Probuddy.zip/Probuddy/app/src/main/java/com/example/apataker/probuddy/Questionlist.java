package com.example.apataker.probuddy;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by APATAKER on 3/30/2018.
 */

public class Questionlist extends ArrayAdapter<Question>{
    private Activity context;
    private List<Question> questionList;

public Questionlist(Activity context,List<Question> questionList){
        super(context,R.layout.question_layout,questionList);
        this.context=context;
        this.questionList=questionList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater =context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.question_layout,null,true);
        TextView a=(TextView)listViewItem.findViewById(R.id.carr1);
        TextView b=(TextView)listViewItem.findViewById(R.id.carr2);

        Question details = questionList.get(position);

        a.setText(details.getA());
        b.setText(details.getB());

        return listViewItem;
    }
}
