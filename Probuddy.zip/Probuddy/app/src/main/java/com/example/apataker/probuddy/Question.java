package com.example.apataker.probuddy;

/**
 * Created by APATAKER on 3/30/2018.
 */

public class Question {

    String a;
    String b;

    public Question()
    {}

    public Question(String a, String b) {
        this.a = a;
        this.b = b;
    }

    public String getA() {
        return a;
    }

    public String getB() {
        return b;
    }


}
