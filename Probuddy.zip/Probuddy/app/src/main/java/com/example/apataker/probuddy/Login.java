package com.example.apataker.probuddy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    Button bin,bup;
    EditText e1,e2;
    FirebaseAuth firebaseAuth;
    ProgressBar progressBar;
    FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();
        bin=(Button)findViewById(R.id.signin);
        bup=(Button)findViewById(R.id.signup);
        e1=(EditText)findViewById(R.id.useredit1);
        e2=(EditText)findViewById(R.id.passedit1);
        progressBar =(ProgressBar)findViewById(R.id.pbLogin);
        if(firebaseAuth.getCurrentUser() !=null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(),Activity.class));
        }
        bup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj2=new Intent(Login.this,Register.class);
                startActivity(obj2);
            }
        });
        bin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLogin();
//                Intent obj2=new Intent(Login.this,Activity.class);
//                startActivity(obj2);
            }
        });
    }
    private void userLogin(){
        String email = e1.getText().toString().trim();
        String pass = e2.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Please Enter Email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass)){
            Toast.makeText(this,"Please Enter Password",Toast.LENGTH_SHORT).show();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        firebaseAuth.signInWithEmailAndPassword(email,pass)
                .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful())
                        {
                            Toast.makeText(Login.this," Success ",Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                            finish();
                            startActivity(new Intent(getApplicationContext(),Activity.class));
                        }else{
                            Toast.makeText(Login.this," Invalid Email and Password ",Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                        }

                    }
                });
    }
}
