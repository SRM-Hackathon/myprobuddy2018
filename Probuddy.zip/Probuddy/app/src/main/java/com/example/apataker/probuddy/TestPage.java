package com.example.apataker.probuddy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CheckBox;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TestPage extends AppCompatActivity {

    private CheckBox ca,cb;
    DatabaseReference db;
    ListView listQuestion;
    List<Question> questionList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_page);
        listQuestion =(ListView)findViewById(R.id.qlist);
        questionList=new ArrayList<>();

    }

    @Override
    protected void onStart() {
        super.onStart();
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                questionList.clear();
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                    Question question=snapshot.getValue(Question.class);
                    questionList.add(question);
                }
//                Questionlist adapter = new Questionlist(Activity.this,questionList);
//                listQuestion.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
