package com.example.apataker.probuddy;

/**
 * Created by APATAKER on 3/30/2018.
 */

public class Details {
    private String custId;
    private String name;
    private String email;
    private String phoneNo;
    private String username;
    private String password;

    public Details()
    {}

    public Details(String custId, String name, String email, String phoneNo, String username, String password) {
        this.custId = custId;
        this.name = name;
        this.email = email;
        this.phoneNo = phoneNo;
        this.username = username;
        this.password = password;
    }

    public String getCustId() {
        return custId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
